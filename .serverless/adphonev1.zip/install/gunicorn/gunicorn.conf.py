bind = "0.0.0.0:8008"
logfile = "/var/log/a2billing-flask-api/a2billing_flask_api.log"
workers = 2
daemon = True
debug = False
pidfile = "/tmp/gunicorn-a2b-flask-api.pid"
